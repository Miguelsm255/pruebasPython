from setuptools import setup

setup(

    name = 'Operadores',
    version = '1.0',
    description = 'Paquete con operadores',
    author = 'Miguelsm255',
    package = ['operadores']

)