# pruebas
En este repositorio estoy subiendo todos los archivos que estoy programando para aprender la sintaxis y el funcionamiento de los lenguajes de programación
